<<<<<<< HEAD
# KPA Backend Assignment

## 🚀 Tech Stack
- FastAPI
- PostgreSQL
- SQLAlchemy
- Pydantic
- dotenv

## ✅ APIs Implemented
1. **POST /bogie/checksheet**: Submit bogie check data
2. **POST /wheel/specification**: Submit wheel specs

## 📦 Setup Instructions

```bash
git clone <repo> or unzip
cd kpa_backend_assignment
python -m venv venv
source venv/bin/activate  # on Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Edit `.env` with your PostgreSQL credentials.

## 🔥 Swagger UI
Visit: `http://127.0.0.1:8000/docs`

## 🧪 Testing
Use Postman to test endpoints:
- `/bogie/checksheet`
- `/wheel/specification`

## 📝 Assumptions
- Basic fields used based on assumed data from Swagger example.
=======
# kpa_backend_task
>>>>>>> 5a156c92163a4cfbed06bffced8f2c3127cd5933
