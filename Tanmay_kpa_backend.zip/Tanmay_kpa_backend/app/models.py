from sqlalchemy import Column, Integer, String, DateTime
from app.database import Base
from datetime import datetime

class BogieChecksheet(Base):
    __tablename__ = "bogie_checksheet"
    id = Column(Integer, primary_key=True, index=True)
    coach_number = Column(String, index=True)
    bogie_number = Column(String)
    inspection_date = Column(DateTime, default=datetime.utcnow)

class WheelSpecification(Base):
    __tablename__ = "wheel_specification"
    id = Column(Integer, primary_key=True, index=True)
    wheel_number = Column(String)
    diameter = Column(String)
    type = Column(String)
