from pydantic import BaseModel

class BogieChecksheetCreate(BaseModel):
    coach_number: str
    bogie_number: str

class WheelSpecificationCreate(BaseModel):
    wheel_number: str
    diameter: str
    type: str
