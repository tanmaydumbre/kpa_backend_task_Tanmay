from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal, engine
from app import models, schemas

models.Base.metadata.create_all(bind=engine)
router = APIRouter(prefix="/bogie", tags=["Bogie"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/checksheet")
def submit_bogie_checksheet(data: schemas.BogieChecksheetCreate, db: Session = Depends(get_db)):
    bogie = models.BogieChecksheet(**data.dict())
    db.add(bogie)
    db.commit()
    db.refresh(bogie)
    return {"message": "Bogie checksheet submitted successfully", "id": bogie.id}
