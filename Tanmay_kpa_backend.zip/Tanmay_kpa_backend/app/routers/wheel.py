from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal, engine
from app import models, schemas

models.Base.metadata.create_all(bind=engine)
router = APIRouter(prefix="/wheel", tags=["Wheel"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/specification")
def submit_wheel_spec(data: schemas.WheelSpecificationCreate, db: Session = Depends(get_db)):
    wheel = models.WheelSpecification(**data.dict())
    db.add(wheel)
    db.commit()
    db.refresh(wheel)
    return {"message": "Wheel specification submitted successfully", "id": wheel.id}
