from fastapi import FastAPI
from app.routers import bogie, wheel

app = FastAPI(title="KPA Form API")

app.include_router(bogie.router)
app.include_router(wheel.router)
